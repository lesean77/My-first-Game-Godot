class_name PlayerFishing
extends Node

signal cast_started
signal cast_power_changed(power: float)
signal cast_power_finished(power: float)

signal bobber_released(start_position: Vector2, target_position: Vector2)
signal bobber_landed(position: Vector2)

signal fish_bitten
signal fishing_finished
signal fishing_cancelled

signal fishing_fight_started
signal fight_values_changed(progress: float, tension: float)

signal fish_caught
signal fish_escaped

@export_category("Bobber")
@export var fishing_bobber_scene : PackedScene

var active_bobber : FishingBobber

enum FishingState {
	NONE,
	PREPARING,
	CASTING,
	WAITING,
	FISH_ON_HOOK,
	FIGHTING,
	REELING,
	CANCELLING,
	FINISHED,
	CANCELLED
}

var player
var player_animation : PlayerAnimation
var player_action
var tool_utils: PlayerToolUtils
var player_attack

var current_equipment: EquipmentData
var state : FishingState = FishingState.NONE

var cast_power: float = 0.0
var cast_direction: float = 1.0
@export var cast_speed: float = 0.8
@export var minimum_cast_power : float = 0.1


var is_fishing : bool = false

@export_category("Cast Disance")
@export var min_cast_distance: float = 8.0
@export var max_cast_distance: float = 80.0

@export var distance_per_rod_damage: float = 4.0
@export var absolute_max_cast_distance: float = 240.0

var pending_cast_position: Vector2 = Vector2.ZERO
var bobber_position: Vector2 = Vector2.ZERO

var bobber_hast_been_released: bool = false

signal bite_indicator_shown
signal bite_indicator_hidden

@export_category("Bite simulation")
@export var min_bite_wait_time: float = 2.0
@export var max_bite_wait_time: float = 6.0
@export var hook_window_duration: float = 1.25

var bite_wait_remaining: float = 0.0
var hook_window_remaining: float = 0.0


@export_category("Fishing Fight")
@export var progress_gain_speed: float = 0.35
@export var progress_loss_speed: float = 0.08

@export var tension_gain_speed: float = 0.5
@export var tension_recovery_speed: float = 0.65

var fight_progress: float = 0.0
var line_tension: float = 0.0
var is_reeling: bool = false

var pending_mouse_position: Vector2 = Vector2.ZERO
var pending_cast_distance: float = 0.0

@export var cancel_cast_duration: float = 0.55

func setup(player_ref, animation_ref, action_ref, tool_utils_ref, attack_ref) -> void:
	player = player_ref
	player_animation = animation_ref
	player_action = action_ref
	tool_utils = tool_utils_ref
	player_attack = attack_ref

# CONSULTAS DE ESTADO
func is_active() -> bool:
	return state != FishingState.NONE

func is_preparing() -> bool:
	return state == FishingState.PREPARING
	
func is_waiting() -> bool:
	return state == FishingState.WAITING

func is_fighting() -> bool:
	return state == FishingState.FIGHTING

# INICIO DA PESCA
func cast_line(equipment: EquipmentData) -> void:
	if is_active():
		return
		
	if equipment == null:
		push_error(
			"PlayerFishing: não foi possivel iniciar a pesca." +
			"EquipmentData é nulo"
		)
		return
	
	if player == null:
		push_error(
			"PlayerFishing: referencia do player nao configurada."
		)
		return
	
	if player_animation == null:
		push_error(
			"PlayerFishing: PlayerAnimation não configurada."
		)
		return
		
	if tool_utils == null:
		push_error(
			"PlayerFishing: PlayerToolUtils nao configurada."
		)
		return
	
	current_equipment = equipment
	
	cast_power = minimum_cast_power
	cast_direction = 1.0
	
	pending_cast_position = Vector2.ZERO
	pending_mouse_position = Vector2.ZERO
	pending_cast_distance = 0.0
	bobber_position = Vector2.ZERO
	bobber_hast_been_released = false
	
	state = FishingState.PREPARING
	
	player_animation.enter_fishing()
	
	cast_started.emit()
	cast_power_changed.emit(cast_power)
	
	print(
		"Pesca iniciada com: ",
		current_equipment.display_name
	)

# ATUALIZAÇÃO
func physics_update(delta: float) -> void:
	match state:
		FishingState.PREPARING:
			update_cast_power(delta)
		
		FishingState.CASTING:
			update_casting(delta)
			
		FishingState.WAITING:
			update_waiting(delta)
			
		FishingState.FISH_ON_HOOK:
			update_fish_on_hook(delta)
			
		FishingState.FIGHTING:
			update_fighting(delta)
			
		FishingState.CANCELLING:
			update_cancelling(delta)
			
func update_cast_power(delta: float) -> void:
	cast_power += cast_direction * cast_speed * delta
	
	if cast_power >= 1.0:
		cast_power = 1.0
		cast_direction = -1.0
		
	elif cast_power <= minimum_cast_power:
		cast_power = minimum_cast_power
		cast_direction = 1.0
		
	cast_power_changed.emit(cast_power)
	
func update_casting(_delta: float) -> void:
	#Posteriormente atualizar trajetoria da boia. 
	pass

func update_waiting(delta: float) -> void:
	bite_wait_remaining -= delta
	
	if bite_wait_remaining > 0.0:
		return
	
	trigger_fish_bite()

func update_fish_on_hook(delta: float) -> void:
	hook_window_remaining -= delta
	
	if hook_window_remaining > 0.0:
		return
		
	fish_escape()

func update_fighting(delta: float) -> void:
	if state != FishingState.FIGHTING:
		return
		
	if is_reeling:
		fight_progress += progress_gain_speed * delta
		line_tension += tension_gain_speed * delta
	else:
		fight_progress -= progress_loss_speed * delta
		line_tension -= tension_recovery_speed * delta
		
	fight_progress = clampf(fight_progress, 0.0, 1.0)
	line_tension = clampf(line_tension, 0.0, 1.0)
	
	fight_values_changed.emit(fight_progress, line_tension)
	
	if line_tension >= 1.0:
		lose_fishing_fight()
		return
		
	if fight_progress >= 1.0:
		win_fishing_fight()
		
	print(
		"Reeling: ", is_reeling,
		" | Progress: ", fight_progress,
		" | Tension: ", line_tension
	)

func update_cancelling(_delta: float) -> void:
	pass
	
func get_facing_direction() -> Vector2:
	if player == null: 
		return Vector2.DOWN
		
	match player.facing:
		player.Facing.DOWN:
			return Vector2.DOWN
			
		player.Facing.UP:
			return Vector2.UP
		
		player.Facing.SIDE:
			return (
				Vector2.LEFT
				if player.facing_left
				else Vector2.RIGHT
			)
		
	return Vector2.DOWN
	
# CONFIRMAÇÃO AO SOLTAR O BOTÃO
func confirm_cast() -> void:
	if state != FishingState.PREPARING:
		return
	
	var effective_power: float = clampf(cast_power, minimum_cast_power, 1.0)
	
	var rod_max_distance: float = get_current_rod_max_distance()
	
	pending_cast_distance = lerpf(
		min_cast_distance,
		rod_max_distance,
		effective_power
	)
	
	pending_cast_distance = clampf(
		pending_cast_distance, 
		min_cast_distance,
		rod_max_distance
	)
	
	pending_mouse_position = player.get_global_mouse_position()
	
	cast_power_finished.emit(effective_power)
	
	state = FishingState.CASTING
	bobber_hast_been_released = false
	
	player_animation.set_fishing_state(&"Cast")
	
	print(
		"Arremesso preparado",
		" | Power: ", effective_power,
		" | Mouse salvo: ", pending_mouse_position,
		" | Alcance máximo: ", rod_max_distance,
		" | Distância escolhida: ", pending_cast_distance
	)
	
# BOIA
func launch_bobber() -> void:
	if state != FishingState.CASTING:
		return
		
	if bobber_hast_been_released:
		return
	
	bobber_hast_been_released = true
	
	var start_position: Vector2 = get_rod_tip_position()
	var to_mouse: Vector2 = pending_mouse_position - start_position
	
	var cast_direction_value: Vector2
	
	if to_mouse.length_squared() <= 0.001:
		cast_direction_value = get_facing_direction()
	else:
		cast_direction_value = to_mouse.normalized()
		
	pending_cast_position = (start_position + cast_direction_value * pending_cast_distance)
	
	bobber_released.emit(start_position, pending_cast_position)
	
	throw_bobber(start_position, pending_cast_position)
	
func get_rod_tip_position() -> Vector2:
	var rod_tip := player.get_node_or_null("RodTip") as Node2D
	
	if rod_tip == null:
		return rod_tip.global_position
		
	var local_tip_position: Vector2 = rod_tip.position
	
	if (player.facing == player.Facing.SIDE and player.facing_left):
		local_tip_position.x = -local_tip_position.x
	
	return player.to_global(local_tip_position)

func get_current_rod_max_distance() -> float:
	var rod_damage: float = 0.0
	
	if current_equipment == null:
		rod_damage = float(current_equipment.damage)
		
	var damage_distance: float = (
		rod_damage * distance_per_rod_damage
	)
	
	var maximum_distance: float = (
		max_cast_distance + damage_distance
	)
	
	return clampf(
		maximum_distance,
		min_cast_distance,
		absolute_max_cast_distance
	)

func throw_bobber(start_position: Vector2, target_position: Vector2) -> void:
	if fishing_bobber_scene == null:
		push_error(
			"PlayerFishing: FishingBobberScene não configurada."
		)
		
		on_bobber_landed(target_position)
		return
		
	remove_active_bobber()
	
	active_bobber = fishing_bobber_scene.instantiate() as FishingBobber
	
	if active_bobber == null:
		push_error(
			"PlayerFishing: a cena instanciada não é FishingBobber."
		)
		
	get_tree().current_scene.add_child(active_bobber)
	active_bobber.setup(
		Callable(self, "get_rod_tip_position")
	)
	
	active_bobber.landed.connect(on_bobber_landed, CONNECT_ONE_SHOT)
	active_bobber.throw_to(start_position, target_position)
	
func on_bobber_landed(position: Vector2) -> void:
	if state != FishingState.CASTING:
		return

	state = FishingState.WAITING

	bobber_landed.emit(position)

	bite_wait_remaining = randf_range(
		min_bite_wait_time,
		max_bite_wait_time
	)
	
	print(
		"Boia pousou em: ",
		position,
		" | Mordida em aproximadamente: ",
		bite_wait_remaining,
		" segundos."
	)

func remove_active_bobber() -> void:
	if not is_instance_valid(active_bobber):
		active_bobber = null
		return
		
	active_bobber.remove_bobber()
	active_bobber = null

func finish_cast_animation() -> void:
	if state != FishingState.CASTING:
		return
	
	if not bobber_hast_been_released:
		return
	
	player_animation.set_fishing_state(&"Waiting")
	
# MORDIDA E LUTA
func trigger_fish_bite() -> void:
	if state != FishingState.WAITING:
		return
		
	state = FishingState.FISH_ON_HOOK
	hook_window_remaining = hook_window_duration
	
	fish_bitten.emit()
	bite_indicator_shown.emit()
	
	print(
		"PUXOU! Você tem ",
		hook_window_duration,
		" segundos para fisgar"
	)
	
func hook_fish() -> void:
	if state != FishingState.FISH_ON_HOOK:
		return
	
	print("Peixe fisgado. Iniciando Minigame")
	
	bite_indicator_hidden.emit()
	
	hook_window_remaining = 0.0
	
	fight_progress = 0.0
	line_tension = 0.0
	is_reeling = false
	
	state = FishingState.FIGHTING
	
	player_animation.set_fishing_state(&"Fighting")
	
	fishing_fight_started.emit()
	fight_values_changed.emit(fight_progress, line_tension)
	
	print("Minigame de pesca iniciado")

func fish_escape() -> void:
	if state != FishingState.FISH_ON_HOOK:
		return
	
	bite_indicator_hidden.emit()
	fish_escaped.emit()
	
	print("O peixe escapou antes da fisgada.")
	
	state = FishingState.WAITING
	
	bite_wait_remaining = randf_range(
		min_bite_wait_time,
		max_bite_wait_time
	)
	
	hook_window_remaining = 0.0
	
	player_animation.set_fishing_state(&"Waiting")
	
# FINALIZAÇÃO
func finish_fishing() -> void:
	if not is_active():
		return
		
	state = FishingState.FINISHED
	
	fishing_finished.emit()
	
	clear_fishing()
	
func cancel_fishing() -> void:
	if not is_active():
		return
		
	if not is_instance_valid(active_bobber):
		finish_cancel_fishing()
		return
	
	if state == FishingState.CANCELLING:
		return
	
	state = FishingState.CANCELLING
	
	bite_indicator_hidden.emit()
	is_reeling = false
	
	player_animation.set_fishing_state(&"CancelCast")
	
	active_bobber.start_returning(
		Callable(self, "get_rod_tip_position"),
		cancel_cast_duration
	)
	
	fishing_cancelled.emit()
	
	clear_fishing()
	
func finish_cancel_fishing() -> void:
	if state != FishingState.CANCELLING:
		return
		
	state = FishingState.CANCELLED
	
	fishing_cancelled.emit()
	
	clear_fishing()
	
func set_reeling(value : bool) -> void:
	if state != FishingState.FIGHTING:
		is_reeling = false
		return
	
	is_reeling = value

func win_fishing_fight() -> void:
	if state != FishingState.FIGHTING:
		return
		
	print("Exemplar Capturado!")
	
	state = FishingState.FINISHED
	is_reeling = false
	
	clear_fishing()
	
	fish_caught.emit()
	
func lose_fishing_fight() -> void:
	if state != FishingState.FIGHTING:
		return
		
	print("O peixe escapou!")
	
	state = FishingState.FINISHED
	is_reeling = false
	
	clear_fishing()
	
	fish_escaped.emit()

func clear_fishing() -> void:
	remove_active_bobber() 
	current_equipment = null
	
	cast_power = 0.0
	cast_direction = 1.0
	
	pending_cast_position = Vector2.ZERO
	pending_mouse_position = Vector2.ZERO
	pending_cast_distance = 0.0
	
	bobber_position = Vector2.ZERO
	bobber_hast_been_released = false
	
	bite_wait_remaining = 0.0
	hook_window_remaining = 0.0
	
	fight_progress = 0.0
	line_tension = 0.0
	is_reeling = false
	
	bite_indicator_hidden.emit()
	
	player_animation.exit_fishing(&"Idle")
	
	state = FishingState.NONE
	
	if player_action != null and player_action.is_busy():
		player_action.finish_action()
		
